package lassonde_hackaton;

public class Driver extends Person 
{
	private String identityInfo;
	public Driver()
	{
		super();
	}

	@Override
	public void setPaymentInfo(String s) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getPaymentInfo() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getIdentityInfo() {
		return identityInfo;
	}

	public void setIdentityInfo(String identityInfo) {
		this.identityInfo = identityInfo;
	}

	@Override
	public String getallInfo() {
		// TODO Auto-generated method stub
		return null;
	}


	
}
