package lassonde_hackaton;

public class InvalidNumberException extends RuntimeException {
    public InvalidNumberException(String message) {
            super(message);
        }
}